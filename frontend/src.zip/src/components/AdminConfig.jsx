import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import '../css/adminConfig.css';

export default function AdminConfig(){
<div className = "containerAdminConfig">
    
</div>



}